
function toggleMenu() {
  const menu = document.getElementById('videoMenu');
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}
